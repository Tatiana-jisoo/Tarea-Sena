from django.db import models

class Grupo(models.Model):
    num_ficha = models.IntegerField(unique=True)
    nombre = models.CharField(max_length=50)

    def __str__(self):
        return self.nombre

class Aprendiz(models.Model):
    identificacion = models.BigIntegerField(unique=True)
    nombre = models.CharField(max_length=50)
    correo = models.CharField(max_length=50, unique=True)
    fecha_nacimiento = models.DateField(blank=True, null=True)
    grupo = models.ForeignKey(Grupo, on_delete=models.CASCADE)
    # Punto 4: Campo teléfono de tipo String(15) que acepta nulos
    telefono = models.CharField(max_length=15, blank=True, null=True)

    def __str__(self):
        return self.nombre