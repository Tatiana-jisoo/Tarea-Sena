from django.contrib import admin
from .models import Grupo, Aprendiz

admin.site.register(Grupo)
admin.site.register(Aprendiz)